from kivy.uix.screenmanager import Screen
from kivymd.uix.dialog import MDDialog
from kivymd.uix.button import MDRaisedButton, MDFlatButton
from kivymd.uix.textfield import MDTextField
from kivymd.uix.boxlayout import MDBoxLayout
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.clock import Clock
from kivy.uix.gridlayout import GridLayout
from kivy.metrics import dp
import database as db
from kivymd.uix.card import MDCard
from kivymd.uix.label import MDLabel
from kivymd.uix.fitimage import FitImage
from kivymd.toast.kivytoast import toast
import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
IMAGES_DIR = os.path.join(BASE_DIR, 'image')

class StockScreen(Screen):
    guide_built = False

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        Clock.schedule_once(lambda dt: self.show_shelves(), 0.1)

    def on_pre_enter(self):
        if not self.guide_built:
            self.build_stock_guide()
            self.guide_built = True
        self.load_stock()

    def load_stock(self):
        self.show_shelves()

    def build_stock_guide(self):
        main_layout = self.ids.main_layout

        title = Label(
            text="[b]⚠️ STOCK LEVEL GUIDE[/b]",
            markup=True,
            font_size="15sp",
            size_hint_y=None,
            height=dp(25),
            color=(1,1,0.3,1)
        )
        main_layout.add_widget(title, index=1)

        legend = BoxLayout(size_hint_y=None, height=dp(45), spacing=dp(20), padding=(dp(5),0))
        legend.add_widget(self.legend_item((1, 0.1, 0.1, 1), "Low"))
        legend.add_widget(self.legend_item((0.2, 0.5, 1, 1), "Half"))
        legend.add_widget(self.legend_item((0, 1, 1, 1), "High"))
        main_layout.add_widget(legend, index=2)

        sep = Label(text="─"*40, color=(0.5,0.5,0.5,1), size_hint_y=None, height=dp(8))
        main_layout.add_widget(sep, index=3)

    def legend_item(self, color, text):
        box = BoxLayout(spacing=dp(2), size_hint_x=None, width=dp(40))
        lbl = Label(text=text, color=(1,1,1,1), font_size="17sp")
        dot = Label(text="|", font_size="30sp", color=color, bold=True, size_hint_y=None, height=dp(50))
        box.add_widget(lbl)
        box.add_widget(dot)
        return box

    def get_stock_color(self, status):
        if status == "Low": return (1, 0.1, 0.1, 1) # Red
        elif status == "Half": return (0.2, 0.5, 1, 1) # Blue - for future
        else: return (0, 1, 1, 1) # Cyan = High

    def get_auto_image_path(self, name, category, db_path):
        if db_path!= 'image/placeholder.png' and os.path.exists(db.get_image_path(db_path)):
            return db.get_image_path(db_path)
        # Auto fallback: image/category/name.png
        auto_path = f"image/{category.lower()}/{name.lower().replace(' ', '_')}.png"
        if os.path.exists(db.get_image_path(auto_path)):
            return db.get_image_path(auto_path)
        return db.get_image_path("image/placeholder.png")

    def show_shelves(self):
        container = self.ids.products_container
        container.clear_widgets()

        categories = ["FOOD", "DRINKS", "HOUSEHOLDS"]
        for cat in categories:
            print(f"\n--- LOADING {cat} ---")
            container.add_widget(Label(text=f"[b]{cat}[/b]", markup=True, size_hint_y=None, height=dp(35)))

            shelf = GridLayout(cols=4, size_hint_y=None, spacing=dp(10), padding=dp(5))
            shelf.bind(minimum_height=shelf.setter('height'))

            products = db.fetch_products_by_category(cat) # already filters qty > 0

            if not products:
                shelf.add_widget(Label(text="No products yet", size_hint_y=None, height=dp(100)))
            else:
                for p in products:
                    prod_id, name, selling_price, img_rel_path, quantity, buying_price, category = p
                    print(f"Building card for: {name}")

                    img_path = self.get_auto_image_path(name, cat, img_rel_path)
                    status = db.get_stock_status(quantity)
                    color = self.get_stock_color(status)

                    card = MDCard(
                        orientation='vertical',
                        size_hint=(None, None),
                        size=(dp(90), dp(150)),
                        padding=dp(0), spacing=dp(3), radius=[dp(8)],
                        line_color=color, line_width=dp(1.5),
                        md_bg_color=(0.15,0.15,0.15,1)
                    )
                    card.add_widget(FitImage(source=img_path, size_hint_y=None, height=dp(70)))
                    card.add_widget(MDLabel(text=name, halign='center', font_size="13sp", size_hint_y=None, height=dp(25)))
                    card.add_widget(MDLabel(text=f"KES {selling_price:,.0f}", halign='center', font_size="10sp", size_hint_y=None, height=dp(20)))
                    card.add_widget(MDLabel(text=f"Qty: {quantity}", halign='center', font_size="8sp", size_hint_y=None, height=dp(18)))
                    shelf.add_widget(card)

            container.add_widget(shelf)
        print("--- DONE LOADING SHELVES ---")

    def create_add_product_dialog(self):
        self.name_field = MDTextField(hint_text="Product Name e.g Oil", mode="fill", fill_color=[0.1, 0.1, 0.15, 0.9])
        self.qty_field = MDTextField(hint_text="Quantity", input_filter="int", mode="fill", fill_color=[0.1, 0.1, 0.15, 0.9])
        self.buy_field = MDTextField(hint_text="Buying Price", input_filter="float", mode="fill", fill_color=[0.1, 0.1, 0.15, 0.9])
        self.sell_field = MDTextField(hint_text="Selling Price", input_filter="float", mode="fill", fill_color=[0.1, 0.1, 0.15, 0.9])
        self.cat_field = MDTextField(hint_text="Category: FOOD, DRINKS, HOUSEHOLDS", text="FOOD", mode="fill", fill_color=[0.1, 0.1, 0.15, 0.9])

        content = MDBoxLayout(self.name_field, self.qty_field, self.buy_field, self.sell_field, self.cat_field,
            orientation="vertical", spacing=dp(12), size_hint_y=None, height=dp(320))

        frost_card = MDCard(content, size_hint=(0.9, None), height=dp(400),
            md_bg_color=[0.05, 0.05, 0.1, 0.7], line_color=[0,0.5,1,1], line_width=1.2, radius=[dp(20)], padding=dp(20))

        dialog = MDDialog(
            title="Add NEW Stock",
            type="custom",
            content_cls=frost_card,
            buttons=[
                MDFlatButton(text="CANCEL", text_color=[1,1,1,0.7], on_release=lambda x: dialog.dismiss()),
                MDRaisedButton(text="SAVE STOCK", md_bg_color=[0,1,1,1], text_color=[0,0,0,1], on_release=lambda x: self.save_product()),
            ],
        )
        return dialog

    def show_add_product_dialog(self):
        if not hasattr(self, 'add_dialog'):
            self.add_dialog = self.create_add_product_dialog()
        self.add_dialog.open()

    def save_product(self):
        name = self.name_field.text.strip()
        qty = self.qty_field.text.strip()
        buy_price = self.buy_field.text.strip()
        sell_price = self.sell_field.text.strip()
        cat = self.cat_field.text.strip()

        if not all([name, qty, buy_price, sell_price, cat]): return

        try:
            qty = int(qty)
            buy_price = float(buy_price)
            sell_price = float(sell_price)
        except: return

        db.add_new_product_to_stock(name, qty, buy_price, sell_price, cat)
        self.show_shelves()

        self.name_field.text = ""
        self.qty_field.text = ""
        self.buy_field.text = ""
        self.sell_field.text = ""
        self.cat_field.text = "FOOD"
        self.add_dialog.dismiss()
        toast(f"{name} added to {cat}")
