from kivymd.uix.screen import MDScreen
from kivymd.app import App
from kivy.clock import Clock
import database as db
from database import get_cash_in_hand, get_total_debt, get_total_debtors
from kivymd.uix.list import OneLineAvatarIconListItem,  ThreeLineAvatarIconListItem, IconLeftWidget

from kivy.properties import NumericProperty
class SalesScreen(MDScreen): 
    cash_out_dialog_box =None
   
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        
        Clock.schedule_once(lambda dt: self.update_stats(), 0.2)
    def on_enter(self):
        self.update_stats()
        self.load_sales("All") # Load on open

    def refresh_screen(self):
        """Call this after a sale is made"""
        self.update_stats() # updates Cash In Hand, Debtors
        self.load_sales("All") # reloads sales history

    def update_stats(self, dt=0):
        print(f"UPDATING SCREEN: {self}")
        """Fetch fresh data from DB"""
        cash, total_sales, expenses = get_cash_in_hand()
        if "cash_in_hand" in self.ids:
            # UPDATE CASH CARD - CYAN
            self.ids.cash_in_hand.text = f"KES {cash}"
            self.ids.total_sales.text = f"Total Sales: {total_sales}"
        debt = get_total_debt()
        debtors = get_total_debtors()
        print(f"DEBUG: debt={debt}, debtors={debtors}")

        if "money_out_label" in self.ids:
            print("IDs found boss")
            print(f"BEFORE: {self.ids.money_out_label.text}")
            self.ids.money_out_label.text = f"KES {debt}"
            self.ids.debtors_label.text = f"Debtors: {debtors}"
            print(f"AFTER: {self.ids.money_out_label.text}")

        else:
            print("ERROR: IDs not found")
        #self.cash_in_hand = cash
        #self.total_sales = total_sales
        #self.money_out = debt  # <-- THIS IS THE 200 FOR JOHN
        #self.debtors_count = debtors # <-- THIS IS THE 1 FOR JOHN

   

    def after_sales(self, period):
        self.load_sales(period)
        self.load_sales("All") 
        
    def load_sales(self, period="All"):
        self.ids.sales_history_list.clear_widgets()
        sales = db.get_sales_history(period)

        if not sales:
            self.ids.sales_history_list.add_widget(
                OneLineAvatarIconListItem(text=f"No {period} sales yet")
            )
            return

        for sale in sales:
            item = ThreeLineAvatarIconListItem(
                text=f"{sale['product_name']}", # Line 1
                secondary_text=f"Qty: {sale['qty_sold']} | KES {sale['total_amount']:,.2f} | {sale['payment_type']}", # Line 2
                tertiary_text=f"{sale['sale_date']}" # Line 3 - Date and Time
            )
            item.add_widget(IconLeftWidget(icon="cart"))
            self.ids.sales_history_list.add_widget(item)

    

        

    def cash_out_dialog(self):
        # Popup to enter amount + reason. Deduct from cash_in_hand
        pass

    def export_report(self):
        # Export current filtered sales to PDF/Excel
        pass

    