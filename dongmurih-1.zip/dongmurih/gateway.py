from kivymd.uix.screen import MDScreen
from kivy.properties import StringProperty,NumericProperty
import os
import socket
from kivymd.uix.dialog import MDDialog
from kivymd.uix.button import MDFlatButton
from payment import PaymentPopup
from firebase_manager import db  # assuming this is firebase_admin
from datetime import datetime, timedelta
import uuid
from kivymd.uix.list import OneLineAvatarIconListItem, IconRightWidget, IconLeftWidget

DEVICE_ID_FILE = "device_id.txt"

def get_device_id():
    if os.path.exists(DEVICE_ID_FILE):
        with open(DEVICE_ID_FILE, "r") as f:
            return f.read().strip()
    new_id = str(uuid.uuid4())
    with open(DEVICE_ID_FILE, "w") as f:
        f.write(new_id)
    return new_id

class GatewayScreen(MDScreen):
    tap_count = NumericProperty(0)
    state = StringProperty('first_time')
    days_left = NumericProperty(0)
    
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.device_id = get_device_id()
        self.selected_plan = None
        self.selected_amount = None
        self.mpesa_code = None
        # NO firebase call here anymore

    def has_internet(self):
        try:
            socket.create_connection(("8.8.8.8", 53), timeout=2)
            return True
        except:
            return False

    def check_user_status(self):
        """Call this when user taps 'Continue' button"""
        if not self.has_internet():
            self.show_dialog("No Internet", "Connect to internet to check subscription")
            return
        
        try:
            ref = db.reference(f"dongmurih/users/{self.device_id}")
            user_data = ref.get()
            
            if user_data and user_data.get("activated") and user_data.get("expiry_date"):
                expiry = datetime.fromisoformat(user_data["expiry_date"])
                if expiry > datetime.now():
                    self.manager.current = "home" # use "home" everywhere
                    return
            
            # Check pending payment
            saved = PaymentPopup.load_selection()
            if saved:
                self.show_payment(saved["plan"], saved["amount"])
                
        except Exception as e:
            self.show_dialog("Server Error", "Could not connect to server")

    def show_payment(self, plan, amount):
        if not self.has_internet():
            self.show_dialog("No Internet", "Connect to internet to pay")
            return
        self.selected_plan = plan
        self.selected_amount = amount
        popup = PaymentPopup(plan, amount, self.on_payment_submitted)
        popup.show() # FIX: was .show()

    def on_payment_submitted(self, plan, amount, mpesa_code):
        if not self.has_internet():
            self.show_dialog("No Internet", "Connect to internet to submit code")
            return

        try:
            # 1. Check if code already used
            if db.reference(f"dongmurih/used_codes/{mpesa_code}").get():
                self.show_dialog("Invalid", "This code is already used or pending")
                return

            # 2. Check first time or renewal
            user_data = db.reference(f"dongmurih/users/{self.device_id}").get()
            is_first_time = not user_data

            # 3. Save to admin queue
            db.reference(f"dongmurih/admin_queue/{mpesa_code}").set({
                "device_id": self.device_id,
                "plan": plan,
                "amount": amount,
                "status": "pending",
                "timestamp": datetime.now().isoformat()
            })
            db.reference(f"dongmurih/used_codes/{mpesa_code}").set(True)

            # 4. Route
            if is_first_time:
                self.manager.current = "setup"
            else:
                self.manager.current = "home"
                home = self.manager.get_screen("home")
                home.waiting_for_approval = True
                home.ids.status_label.text = f"Payment Submitted: {mpesa_code}\nWaiting for Admin Approval..."
                home.ids.connect_btn.disabled = True

        except Exception as e:
            self.show_dialog("Error", "Failed to submit. Check internet.")

    def on_plan_monthly(self): self.show_payment("Monthly", 499)
    def on_plan_yearly(self): self.show_payment("Yearly", 4500)

    def check_admin_tap(self, touch):
        if self.ids.logo.collide_point(*touch.pos):
            self.tap_count += 1
            if self.tap_count >= 5:
                self.tap_count = 0
                self.manager.current = "admin_login"

    def show_dialog(self, title, text):
        dialog = MDDialog(title=title, text=text, buttons=[MDFlatButton(text="OK", on_release=lambda x: dialog.dismiss())])
        dialog.open()   
       

class AdminDashboardScreen(MDScreen):
    def on_enter(self):
        if GatewayScreen().has_internet(): # reuse the check
            self.load_queue()
        else:
            self.show_dialog("No Internet", "Connect to load queue")
            
    def load_queue(self):
        try:
            self.ids.list.clear_widgets()
            queue = db.reference("dongmurih/admin_queue").get()
            if queue:
                for code, data in queue.items():
                    item = OneLineAvatarIconListItem(
                        text=f"{code} - {data['plan']} - {data['device_id'][:8]}",
                        on_release=lambda x, c=code, d=data: self.approve(c, d)
                    )
                    item.add_widget(IconLeftWidget(icon="check"))
                    self.ids.list.add_widget(item)
        except: pass

    def approve(self, code, data):
        days = 30 if data["plan"] == "Monthly" else 365
        expiry_date = datetime.now() + timedelta(days=days)
        db.reference(f"dongmurih/users/{data['device_id']}").update({
            "activated": True,
            "plan": data["plan"],
            "expiry_date": expiry_date.isoformat()
        })
        db.reference(f"dongmurih/used_codes/{code}").set(True)
        db.reference(f"dongmurih/admin_queue/{code}").delete()
        self.load_queue()

    def show_dialog(self, title, text):
        dialog = MDDialog(title=title, text=text, buttons=[MDFlatButton(text="OK", on_release=lambda x: dialog.dismiss())])
        dialog.open()
