from kivy.uix.boxlayout import BoxLayout
from kivy.properties import StringProperty, NumericProperty, BooleanProperty, ObjectProperty
from kivy.animation import Animation
from kivy.metrics import dp
from kivymd.uix.screen import MDScreen
from kivymd.uix.list import OneLineListItem
from kivy.app import App
from database import (
    get_all_unpaid_debts,
    get_total_profit_out_on_deni,
    get_debt_items
)

class DebtorsListItem(BoxLayout):
    debt_id = NumericProperty()
    debtor_name = StringProperty()
    number_text = StringProperty()
    phone = StringProperty()
    total_amount = NumericProperty()
    profit = NumericProperty()
    date_lent = StringProperty()

    is_expanded = BooleanProperty(False)

    def toggle_expand(self):
        content = self.ids.expand_content
        arrow = self.ids.arrow_icon

        if self.is_expanded:
            # Collapse
            anim = Animation(height=0, opacity=0, duration=0.2)
            arrow.icon = "chevron-down"
        else:
            # Expand - load products first
            self.load_products()
            content.height = content.minimum_height
            anim = Animation(height=content.minimum_height, opacity=1, duration=0.2)
            arrow.icon = "chevron-up"

        anim.start(content)
        self.is_expanded = not self.is_expanded

    def load_products(self):
        container = self.ids.products_container
        container.clear_widgets()

        items = get_debt_items(self.debt_id)
        for item in items:
            # item = (product_id, name, qty, price, subtotal)
            name, qty, price, subtotal = item[1], item[2], item[3], item[4]
            text = f"{name} - {qty} x Ksh {price:.2f} = Ksh {subtotal:.2f}"
            container.add_widget(
                OneLineListItem(text=text, theme_text_color="Secondary")
            )

        # Set totals and date
        self.ids.total_amount_label.text = f"Total: Ksh {self.total_amount:.2f}"
        self.ids.date_label.text = f"Date: {self.date_lent}"

    def collect_debt(self):
        # This will be chunk 4
        app = App.get_running_app()
        app.root.get_screen('denibook').collect_debt(self.debt_id, self.total_amount, self.profit)

class DenibookScreen(MDScreen):
    def on_enter(self):
        """Refresh every time we open screen"""
        self.load_denibook()

    def load_denibook(self):
        print("UNPAID DEBTS:", get_all_unpaid_debts)
        # 1. Update top stat
        total_profit = get_total_profit_out_on_deni()
        self.ids.total_profit_out_label.text = f"Ksh {total_profit:,.2f}"

        # 2. Load debtors list
        container = self.ids.debtors_list_container
        container.clear_widgets()

        debts = get_all_unpaid_debts()
        for i, debt in enumerate(debts, start=1):
            # debt = (id, customer_id, customer_name, phone, total_amount, profit, date_lent)
            item = DebtorsListItem(
                debt_id=debt[0],
                debtor_name=debt[2],
                phone=debt[3],
                total_amount=debt[4],
                profit=debt[5],
                date_lent=debt[6],
                number_text=f"{i}."
            )
            container.add_widget(item)

    def collect_debt(self, debt_id, amount, profit):
        """Placeholder - Chunk 4 will fill this"""
        print(f"Collecting debt {debt_id}: Amount={amount}, Profit={profit}")
        # TODO: update DB, update cash, update home profit, refresh list


