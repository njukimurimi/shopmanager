from kivymd.app import MDApp
from kivy.lang import Builder
from kivy.uix.screenmanager import ScreenManager, Screen
from datetime import datetime, timedelta
from kivy.core.window import Window
import json, os
from setup_screen import SetupScreen
from database import create_tables
from homescreen import HomeScreen
from mainscreen import MainScreen
from products_screen import ProductsScreen
from stock_screen import StockScreen
from sales_screen import SalesScreen
from denibook import DenibookScreen
from gateway import GatewayScreen
from firebase_manager import db
import database
from kivymd.uix.dialog import MDDialog
from kivy.uix.popup import Popup
from kivy.clock import Clock
from kivy.animation import Animation
#from kivymd.uix.boxlayout import MDBoxLayout # or FitImage if you use that
from kivy.uix.image import Image
from kivy.properties import NumericProperty, StringProperty


USER_FILE = 'user_data.json'
Window.size = (360, 700)
class AddProductPopup(MDDialog): pass


class RotatingLogo(Image):
    angle = NumericProperty(0)
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        anim = Animation(angle=360, duration=40)
        anim += Animation(angle=0, duration=0)
        anim.repeat = True
        #anim.start(self)

    def pause_logo(self):
        self.anim.cancel(self)  # pause

    def resume_logo(self):
        self.anim.start(self)   # resume

    
       

class DongMurihApp(MDApp):
    username = StringProperty("USER") # default name
    products = [] # MASTER LIST for both scr
    cash_in_hand = 12450
    total_sales = 87
   
    username = ""
    #db = Database()
    def build(self):
        #self.db = Database()
        self.theme_cls.primary_palette = "Cyan"
        self.theme_cls.theme_style = "Dark"
       

        Builder.load_file('dongmurih.kv')
       
        self.sm = ScreenManager()
        
        self.sm.add_widget(SetupScreen(name='setup'))
        self.sm.add_widget(GatewayScreen(name='gateway'))
        self.sm.add_widget(HomeScreen(name='home'))
        self.sm.add_widget(MainScreen(name='main'))
        self.sm.add_widget(ProductsScreen(name='products'))
        self.sm.add_widget(StockScreen(name='stock'))
        self.sm.add_widget(SalesScreen(name='sales'))
        self.sm.add_widget(DenibookScreen(name='denibook'))
        self.sm.current = 'main'
        #self.check_gateway() # RUN GATE CHECK ON START
        return self.sm
        
    def check_access(self):
        device_id = device_id()
        user = db.child("users").child(device_id).get()
        if not user or not user.get("activated"):
            self.root.current = "gateway"
        elif datetime.now() > datetime.fromisoformat(user["expiry_date"]):
            self.root.current = "gateway" # Expired
        else:
            self.root.current = "main"
    def save_username(self, name):
        self.username = name
        with open(USER_FILE, 'w') as f:
            json.dump({'username': name}, f)
        self.root.current = 'main'
    def show_add_product_popup(self):
            
        AddProductPopup().open()
    def check_gateway(self):
        today = datetime.now().date()

        activated = self.db.get_setting('activated')
        expiry_str = self.db.get_setting('expiry_date')
        last_check_str = self.db.get_setting('last_check_date')
        username = self.db.get_setting('username')

        # Update last_check_date every open
        self.db.save_setting('last_check_date', str(today))

        # 1. NOT ACTIVATED AT ALL
        if activated!= 'true':
            self.sm.current = 'gateway'
            self.sm.get_screen('gateway')
            return

        # 2. ANTI CLOCK TRICK
        if last_check_str:
            last_check = datetime.strptime(last_check_str, "%Y-%m-%d").date()
            if today < last_check:
                self.sm.current = 'gateway'
                self.sm.get_screen('gateway').set_state('tampered')
                return

        # 3. CHECK EXPIRY + GRACE
        if expiry_str:
            expiry = datetime.strptime(expiry_str, "%Y-%m-%d").date()
            grace_end = expiry + timedelta(days=3)

            if today > grace_end: # HARD BLOCK AFTER GRACE
                self.sm.current = 'gateway'
                self.sm.get_screen('gateway').set_state('expired_blocked')
                return
            elif today > expiry: # IN GRACE PERIOD
                self.sm.current = 'gateway'
                days_left = (grace_end - today).days
                self.sm.get_screen('gateway').set_state('grace', days_left)
                return # But user can still go to home if they press continue

        # 4. NEED USERNAME
        if username == '':
            self.sm.current = 'setup'
            return

        # 5. ALL GOOD
        self.sm.current = 'home'
        self.sm.current = 'main'

    def activate_subscription(self, plan):
        """Called when user pays. plan = 'monthly' or 'yearly'"""
        today = datetime.now().date()

        if plan == 'monthly':
            days = 30
        else:
            days = 365

        # If renewing, add to old expiry. If new, add to today
        expiry_str = self.db.get_setting('expiry_date')
        if expiry_str:
            old_expiry = datetime.strptime(expiry_str, "%Y-%m-%d").date()
            base_date = max(today, old_expiry) # don't lose days
        else:
            base_date = today
            self.db.save_setting('activated', 'true')
            self.db.save_setting('activation_date', str(today))

        new_expiry = base_date + timedelta(days=days)

        self.db.save_setting('plan', plan)
        self.db.save_setting('expiry_date', str(new_expiry))

        # After payment, go set username if not set
        if self.db.get_setting('username') == '':
            self.sm.current = 'home'
        else:
            self.sm.current = 'setup'



create_tables()
DongMurihApp().run()

