from kivymd.uix.screen import MDScreen
import database as db
from kivymd.uix.card import MDCard
from kivymd.uix.label import MDLabel
from kivymd.uix.fitimage import FitImage
from kivy.uix.label import Label
from kivy.clock import Clock
from kivy.uix.gridlayout import GridLayout
from kivy.metrics import dp
from kivy.uix.image import Image
from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
import os
from kivy.uix.behaviors import ButtonBehavior
from kivy.uix.floatlayout import FloatLayout
from kivymd.uix.dialog import MDDialog
from kivymd.uix.button import MDFlatButton
from kivymd.uix.textfield import MDTextField
from kivy.properties import ListProperty, DictProperty
from database import save_debt_new, get_total_debt, get_total_debtors
from kivy.uix.popup import Popup
class ProductsScreen(MDScreen):
    #cart = {} # {prod_id: {'data':..., 'qty':...}}
    lend_dialog = None
    name_field = None
    phone_field = None
    cart = ListProperty([])
    cart_widgets = DictProperty({}) # tracks {product_id: widget}

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.cart = []
        self.cart_widgets = {}
        Clock.schedule_once(lambda dt: self.show_shelves(), 0.1)
        Clock.schedule_once(lambda dt: self.update_cart_ui(), 0.2)

    def get_auto_image_path(self, name, category, db_path):
        if db_path!= 'image/placeholder.png' and os.path.exists(db.get_image_path(db_path)):
            return db.get_image_path(db_path)
        auto_path = f"image/{category.lower()}/{name.lower().replace(' ', '_')}.png"
        if os.path.exists(db.get_image_path(auto_path)):
            return db.get_image_path(auto_path)
        return db.get_image_path("image/placeholder.png")
    def show_shelves(self):
        container = self.ids.products_container
        container.clear_widgets()

        categories = ["FOOD", "DRINKS", "HOUSEHOLDS"]
        for cat in categories:
            container.add_widget(Label(text=f"[b]{cat}[/b]", markup=True, size_hint_y=None, height=dp(35), color=(0,1,1,1)))

            shelf = GridLayout(cols=4, size_hint_y=None, spacing=dp(10), padding=dp(5))
            shelf.bind(minimum_height=shelf.setter('height'))

            products = db.fetch_products_by_category(cat)

            if not products:
                shelf.add_widget(Label(text="No products yet", size_hint_y=None, height=dp(100), color=(1,1,1,0.5)))
            else:
                for p in products:
                    prod_id, name, selling_price, img_rel_path, quantity, buying_price, category = p

                    img_path = self.get_auto_image_path(name, cat, img_rel_path)

                    prod_data = {
                        'id': prod_id, 'name': name, 'selling_price': selling_price,
                        'buying_price': buying_price, 'image_path': img_path
                    }

                    card = ProductCard(prod_data, self.add_to_cart) # ONLY 1 CARD TYPE
                    shelf.add_widget(card) # ONLY ADD TO THIS SHELF

            container.add_widget(shelf) # ADD SHELF TO MAIN CONTAINER

   
    
    def add_to_cart(self, prod_data, widget):
        prod_id = prod_data['id']

        if prod_id in self.cart_widgets: # already in cart = remove it
            self.cart = [item for item in self.cart if item['id']!= prod_id]
            del self.cart_widgets[prod_id]
            widget.set_selected(False)
        else: # add to cart
            self.cart.append({
                'id': prod_id,
                'name': prod_data['name'],
                'qty': 1, # default 1. we can add +/- later
                'selling_price': prod_data['selling_price'],
                'buying_price': prod_data['buying_price']
            })
            self.cart_widgets[prod_id] = widget
            widget.set_selected(True)

        self.update_cart_ui()
    def update_cart_ui(self):
        self.cart_count = sum([item['qty'] for item in self.cart])
        self.cart_total = sum([item['qty'] * item['selling_price'] for item in self.cart])
        self.ids.cart_count_label.text = str(self.cart_count)
        self.ids.cart_total_label.text = f"KES {self.cart_total:,.0f}"
        # make icon gold when items in cart
        self.ids.cart_icon.text_color = (1,0.84,0,1) if self.cart_count > 0 else (0,1,0,1)
    def on_sell(self):
        if not self.cart: 
            return

        # 1. GET payment type. Add a dropdown in KV if you want Mpesa/Deni
        payment_type = 'Cash' # default to Cash. Change this to self.ids.payment_dropdown.text later

        # 2. BUILD cart_items AND save to DB
        cart_items = []
        for item in self.cart:
            total_amount = item['qty'] * item['selling_price']
            cart_items.append({
                'id': item['id'],
                'qty': item['qty'],
                'selling_price': item['selling_price'],
                'buying_price': item['buying_price'],
                'name': item['name'],
                'total_amount': total_amount # add this so DB has it
            })

        # This should save all items + update stock + cash in DB
        profit_made = db.sell_product(cart_items, payment_type=payment_type) 

        # 3. CLEAR UI
        for widget in self.cart_widgets.values():
            widget.set_selected(False)
        
        self.cart = []
        self.cart_widgets = {}
        self.update_cart_ui()
        self.show_shelves()

        # 4. THE WIRE: Refresh other screens
        app = App.get_running_app()
        home_screen = app.root.get_screen('home')
        home_screen.update_stats() 
        
        sales_screen = app.root.get_screen('sales') # must match name in ScreenManager
        sales_screen.refresh_screen() # This will reload Sales History

        print(f"Sold! Profit: KES {profit_made}")
        #self.show_snackbar(f"Sale completed! Profit: KES {profit_made:,.0f}")

    
    def on_lend(self):
        """Called when LEND button is clicked"""
        if not self.cart:
            self.show_popup("Cart Empty", "Add items to cart first")
            return
        self.show_lend_popup()

    def show_lend_popup(self):
        if self.lend_dialog:
            self.lend_dialog.dismiss()

        # Calculate total from cart
        cart_total = sum([item['selling_price'] * item['qty'] for item in self.cart])

        # Container
        content = BoxLayout(orientation="vertical", spacing=dp(15), size_hint_y=None, height=dp(220), padding=dp(10))

        # Show Total Amount - not editable
        total_label = MDLabel(
            text=f"Total Amount: KES {cart_total:.2f}",
            theme_text_color="Custom",
            text_color=(0,1,1,1), # Neon cyan
            halign="center",
            font_style="H6"
        )

        # Debtor Name Field
        self.name_field = MDTextField(
            hint_text="Debtor's Name",
            hint_text_color=(1,1,1,0.8), # white hint
            text_color=(0,1,1,1), # neon cyan when typing
            line_color_focus=(0,1,1,1), # neon cyan border when active
            line_color_normal=(0,1,1,1), # neon cyan border when not active
            mode="round",
            required=True
        )

        # Phone Number Field - Optional
        self.phone_field = MDTextField(
            hint_text="Phone Number - Optional",
            hint_text_color=(1,1,1,0.8), # white hint
            text_color=(0,1,1,1), # neon cyan when typing
            line_color_focus=(0,1,1,1), # neon cyan border when active
            line_color_normal=(0,1,1,1), # neon cyan border when not active
            mode="round",
            input_type="number"
        )

        content.add_widget(total_label)
        content.add_widget(self.name_field)
        content.add_widget(self.phone_field)

        self.lend_dialog = MDDialog(
            title="LEND ITEM",
            type="custom",
            content_cls=content,
            radius=[20, 20, 20, 20],
            md_bg_color=[0.3, 0, 0, 0.6], # More transparent red frost glass
            elevation=0,
            buttons=[
                MDFlatButton(
                    text="CANCEL",
                    text_color=(0,1,1,1), # Neon Cyan button
                    on_release=lambda x: self.lend_dialog.dismiss()
                ),
                MDFlatButton(
                    text="SAVE",
                    text_color=(0,0.5,1,1), # Blue button
                    on_release=lambda x: self.save_debt(cart_total)
                ),
            ],
        )
        self.lend_dialog.open()

    def save_debt(self, total_amount):
        name = self.name_field.text.strip()
        phone = self.phone_field.text.strip()
        if not name: 
            return

        created_by = 'admin' 
        role = 'employer'

        # Save using new function - NOW WITH payment_type='Deni'
        amount, profit = save_debt_new(name, phone, self.cart, created_by, role, payment_type='Deni')

        # Update SalesScreen stats
        app = App.get_running_app()
        sales_screen = app.root.get_screen('sales')
        sales_screen.money_out = get_total_debt()
        sales_screen.debtors_count = get_total_debtors()
        sales_screen.update_stats()

        # CLEAR CART
        for widget in self.cart_widgets.values():
            widget.set_selected(False)
        self.cart = []
        self.cart_widgets = {}
        self.update_cart_ui()
        self.lend_dialog.dismiss()
        print(f"Debt saved for {name}: KES {amount}")
    
    def filter_products(self, text): pass # keep your existing
    def filter_by_category(self, cat): pass # keep your existing



def get_auto_image_path(filename):

    return os.path.join("products_images",filename )

class ProductCard(MDCard):
    def __init__(self, prod_data, toggle_cart_callback, **kwargs):
        super().__init__(**kwargs)
        self.prod_data = prod_data
        self.toggle_cart_callback = toggle_cart_callback
        self.selected = False

        self.orientation = "vertical"
        self.size_hint = (None, None)
        self.size = (dp(90), dp(120))
        self.padding = dp(3)
        self.spacing = dp(3)
        self.radius = [dp(8)]
        self.md_bg_color = (0.15,0.15,0.15,1)
        self.elevation = 2
        self.ripple_behavior = True # this gives ripple + makes it clickable

        # CONTENT
        self.img = FitImage(source=prod_data['image_path'], size_hint_y=None, height=dp(70))
        self.name_label = MDLabel(text=prod_data['name'], halign='center', font_size="12sp", size_hint_y=None, height=dp(22))
        self.price_label = MDLabel(text=f"KES {prod_data['selling_price']:,.0f}", halign='center', font_size="13sp", bold=True, size_hint_y=None, height=dp(20), theme_text_color="Custom", text_color=(0,1,1,1))
        
        self.add_widget(self.img)
        self.add_widget(self.name_label)
        self.add_widget(self.price_label)

    def on_touch_down(self, touch): # THIS IS THE KEY
        if self.collide_point(*touch.pos):
            self.toggle_cart_callback(self.prod_data, self)
            return True # consume the touch
        return super().on_touch_down(touch)

    def set_selected(self, selected):
        self.selected = selected
        if selected:
            self.md_bg_color = (0, 1, 1, 0.4) # cyan when selected
            self.elevation = 8
        else:
            self.md_bg_color = (0.15,0.15,0.15,1) # dark when not
            self.elevation = 2

