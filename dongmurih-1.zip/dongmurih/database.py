import os, sqlite3
from datetime import datetime
import json
from datetime import date

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, "dongmurih.db")
IMAGES_DIR = os.path.join(BASE_DIR, 'image')
print("THIS DB IS:", os.path.abspath(DB_PATH))
IMG_FOLDER = 'image'
DATA_FILE = 'products.json'


def get_connection(db_path=DB_PATH):
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn





def get_all_stock():
    conn = get_connection(DB_PATH)
    cur = conn.cursor()
    cur.execute("SELECT id, name, quantity, buying_price, selling_price, category, image_path  FROM stock ORDER BY name")
    rows = cur.fetchall()
    conn.close()
    return rows

def record_sale(product_name, qty_sold, selling_price, buying_price):
    profit = (selling_price - buying_price) * qty_sold
    today = datetime.now().strftime("%Y-%m-%d")
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("INSERT INTO sales (product_name, qty_sold, selling_price, buying_price, profit,date) VALUES (?, ?, ?, ?, ?, ?)",
                (product_name, qty_sold, selling_price, buying_price, profit,today))
    conn.commit()
    conn.close() 






def update_stock(product_id, new_quantity):
      """Update product quantity"""
      conn = get_connection()
      cur = conn.cursor()
      cur.execute("UPDATE products SET stock =? WHERE id =?", (new_quantity, product_id))
      conn.commit()
      conn.close()


def add_category(name):
      conn = get_connection()
      cur = conn.cursor()
      try:
            cur.execute("INSERT INTO categories (name) VALUES (?)", (name,))
            conn.commit()
            return cur.lastrowid
      except:
            return None
      finally:
            conn.close()

def get_stock_summary():
      """Returns total products, low stock, out of stock, total stock value"""
      conn = get_connection()
      cur = conn.cursor()

      cur.execute(" SELECT COUNT(*) FROM products")
      total_products = cur.fetchone()[0]

      cur.execute("SELECT COUNT(*)8 FROM products WHERE quantity = 0")
      out_of_stock = cur.fetchone()[0]

      cur.execute("SELECT COUNT (*) FROM products WHERE quantity > 0 AND quantity <= 5")
      low_stock = cur.fetchone()[0]

      cur.execute("SELECT COALESCE(SUM(price * quantity), 0) FROM products")
      stock_value = cur.fetchone()[0]

      conn.close()
      return {
            'total_products': total_products,
            'out_of_stock': out_of_stock,
            'low_stock': low_stock,
            'stock_value': stock_value
      }

#+++++ SALE +++++
def get_today_sales():
    """Today's Sales count + total amount"""
    conn = get_connection()
    cur = conn.cursor()
    today = datetime.now().strftime("%Y-%m-%d")

    cur.execute("""
        SELECT COUNT(*) as count, COALESCE(SUM(total_amount), 0) as total
        FROM sales
        WHERE DATE(sale_date) = ?""", (today, ))
    row = cur.fetchone()
    conn.close()
    return {'count': row['count'], 'total': row['total']}

def create_sale(caart_items, total_amount, total_profit):
    conn = get_connection()
    cur = conn.cursor() 
    sale_date = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    cur.execute("INSERT INTO sales (sale_date, total_amount, total_profit) VALUES (?, ?, ?)",
                (sale_date, total_amount, total_profit))
    sale_id = cur.lastrowid
    conn.commit()
    conn.close()
    return sale_id

def create_sale_items(sale_id, cart_items):
    conn = get_connection()
    cur = conn.cursor()

    for item in cart_items:
        stock_id = item['id']
        qty = item['qty']
        buy = item['buying_price']
        sell = item['selling_price']
        profit = (sell - buy) * qty

        cur.execute(""" INSERT INTO sale_items
                    (sale_id, stock_id, quantity_sold,buying_price, selling_price, profit)
                    VALUES (?, ?, ?)""",
                    (sale_id, stock_id, qty, buy, sell, profit))
        cur.execute("UPDATE stock SET quantity =? WHERE id =? ", (qty, stock_id))
        conn.commit()
        conn.close()
def get_all_products():
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT id, name, quantity,buying_price, selling_price FROM stock WHERE quantity > 0")
    products = [dict(row) for row in cur.fetchall()]
    conn.close()
    return products 


def checkout(cart_items):
    """
    cart_items = [{'product_id': 1, 'qty': 2, 'price': 500}, ...]
    Returns sale_id if success, None if failed

            """
    conn = get_connection()
    cur = conn.cursor()

    try:
        total_amount = sum(item['qty'] * item['price'] for item in cart_items)

        cur.execute("INSERT INTO sales (sale_date, total_amount) VALUES (?, ?)",
                    (datetime.now(), total_amount))
        sale_id = cur.lastrowid

        for item in cart_items:
                cur.execute("INSERT INTO sale_items (sale_id, product_id, quantity, price) VALUES(?, ?, ?)",
                           (sale_id, item['product_id'], item['qty'], item['price']))
                    
                cur.execute("UPDATE products SET quantity = quantity -? WHERE id =?",
                              (item['qty'], item['product_id']))
                  
                conn.commit()
                return sale_id
    except Exception as e:
        conn.rollback()
        print(f"Checkout error : {e}")
        return None
    finally:
          conn.close()

def get_sales_history(limit=50):
    """Get recent sales"""
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("""
        SELECT id, sale_date, total_amount
        FROM sales
        ORDER BY sale_date DESC
        LIMIT?
    """, (limit, ))
    sales = [dict(row) for row in cur.fetchall()]
    conn.close()
    return sales
      

    
def get_image_path(img_name):
    """Always return full path inside /image folder"""
    if not img_name or img_name.strip() == "":
        img_name = "placeholder.png"
    
    # Strip any folder from it, we only want filename
    filename = os.path.basename(img_name)
    
    full_path = os.path.join(IMAGES_DIR, filename)
    print(f"Checking image: {full_path} Exists: {os.path.exists(full_path)}")
    
    if os.path.exists(full_path):
        return full_path
    else:
        # fallback to placeholder
        return os.path.join(IMAGES_DIR, "placeholder.png")
   



def get_categories():
      """GET all categories"""
      conn = get_connection(DB_PATH)
      cur = conn.cursor()
      cur.execute("SELECT name FROM categories WHERE name!= 'category_name'")
      cats = [row[0] for row in cur.fetchall()]
      print("Raw categories from DB:", cats)
      print("Total cardss will be:", len(cats))
      conn.close()
      return cats

def add_category(name):
      conn = get_connection()
      cur = conn.cursor()
      try:
            cur.execute("INSERT INTO categories (name) VALUES (?)", (name,))
            conn.commit()
            return cur.lastrowid
      except:
            return None
      finally:
            conn.close()

def get_stock_summary():
      """Returns total products, low stock, out of stock, total stock value"""
      conn = get_connection()
      cur = conn.cursor()

      cur.execute(" SELECT COUNT(*) FROM products")
      total_products = cur.fetchone()[0]

      cur.execute("SELECT COUNT(*)8 FROM products WHERE quantity = 0")
      out_of_stock = cur.fetchone()[0]

      cur.execute("SELECT COUNT (*) FROM products WHERE quantity > 0 AND quantity <= 5")
      low_stock = cur.fetchone()[0]

      cur.execute("SELECT COALESCE(SUM(price * quantity), 0) FROM products")
      stock_value = cur.fetchone()[0]

      conn.close()
      return {
            'total_products': total_products,
            'out_of_stock': out_of_stock,
            'low_stock': low_stock,
            'stock_value': stock_value
      }

#+++++ SALE +++++
def add_sale(product_name, qty_sold, sell_price, total_amount, payment_type):
    conn = get_connection(DB_PATH)
    cur = conn.cursor()
    cur.execute("""
        INSERT INTO sales (product_name, qty_sold, sell_price, total_amount, payment_type) 
        VALUES (?, ?, ?, ?, ?)
    """, (product_name, qty_sold, sell_price, total_amount, payment_type))
    conn.commit()
    conn.close()


def get_today_sales():
    """Today's Sales count + total amount"""
    conn = get_connection()
    cur = conn.cursor()
    today = datetime.now().strftime("%Y-%m-%d")

    cur.execute("""
        SELECT COUNT(*) as count, COALESCE(SUM(total_amount), 0) as total
        FROM sales
        WHERE DATE(sale_date) = ?""", (today, ))
    row = cur.fetchone()
    conn.close()
    return {'count': row['count'], 'total': row['total']}

def checkout(cart_items):
    """
    cart_items = [{'product_id': 1, 'qty': 2, 'price': 500}, ...]
    Returns sale_id if success, None if failed

            """
    conn = get_connection()
    cur = conn.cursor()

    try:
        total_amount = sum(item['qty'] * item['price'] for item in cart_items)

        cur.execute("INSERT INTO sales (sale_date, total_amount) VALUES (?, ?)",
                    (datetime.now(), total_amount))
        sale_id = cur.lastrowid

        for item in cart_items:
                cur.execute("INSERT INTO sale_items (sale_id, product_id, quantity, price) VALUES(?, ?, ?)",
                           (sale_id, item['product_id'], item['qty'], item['price']))
                    
                cur.execute("UPDATE products SET quantity = quantity -? WHERE id =?",
                              (item['qty'], item['product_id']))
                  
                conn.commit()
                return sale_id
    except Exception as e:
        conn.rollback()
        print(f"Checkout error : {e}")
        return None
    finally:
          conn.close()
def add_stock(prod_id, qty_to_add):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("UPDATE products SET stock = stock + ? WHERE id=?", (qty_to_add, prod_id))
    conn.commit()
    conn.close()



def get_sales_history(limit=50):
    """Get recent sales"""
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("""
        SELECT id, sale_date, total_amount
        FROM sales
        ORDER BY sale_date DESC
        LIMIT?
    """, (limit, ))
    sales = [dict(row) for row in cur.fetchall()]
    conn.close()
    return sales
      

def create_tables():
    conn = get_connection(DB_PATH)
    cur = conn.cursor()

    
    cur.execute(""" 
        CREATE TABLE IF NOT EXISTS categories(
            id INTEGER PRIMARY KEY AUTOINCREMENT ,
            name TEXT UNIQUE NOT NULL     )
    """)

    cur.execute('''CREATE TABLE IF NOT EXISTS stock
                (id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                quantity INTEGER DEFAULT 0,
                buying_price REAL DEFAULT 0 ,
                qty INTEGER DEFAULT 0, 
                selling_price REAL DEFAULT 0, 
                category TEXT DEFAULT 'others',
                image_path TEXT DEFAULT 'images/placeholder.png')''')
    
    cur.execute("""
        CREATE TABLE IF NOT EXISTS products(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            quantity INTEGER DEFAULT 0,
            buying_price REAL DEFAULT 0,
            selling_price REAL NOT NULL,
            category TEXT NOT NULL,
            image_path TEXT DEFAULT 'image/placeholder.png',
            stock_status TEXT DEFAULT 'High',
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            UNIQUE(name, category)
        )
    """)    

    cur.execute(""" 
        CREATE TABLE IF NOT EXISTS cart (
            id INTEGER PRIMARY KEY AUTOINCREMENT, 
            product_id INTEGER, 
            qty INTEGER
        )
    """)

    cur.execute(""" 
    CREATE TABLE IF NOT EXISTS sales_new (
        id INTEGER PRIMARY KEY AUTOINCREMENT, 
        receipt_no INTEGER UNIQUE,
        total_amount REAL NOT NULL,
        payment_type TEXT DEFAULT 'Cash', -- Cash, Mpesa, Debt
        date DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    """)

    cur.execute(""" 
        CREATE TABLE IF NOT EXISTS sales (
            id INTEGER PRIMARY KEY AUTOINCREMENT, 
            product_id INTEGER,
            sold_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            qty_sold INTEGER,
            product_name TEXT,
            buy_price REAL,
            sell_price REAL,
            qty INTEGER,
            sale_price REAL,
            total_profit REAL,
            cost_price REAL,
            total_amount REAL NOT NULL,
            payment_type TEXT DEFAULT 'Cash',
            sale_date TEXT,
            profit REAL
        )
    """)
    
    cur.execute("""
        CREATE TABLE IF NOT EXISTS Sale_items(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            sale_id INTEGER NOT NULL, 
            stock_id INTEGER NOT NULL,
            quantity_sold INTEGER NOT NULL, 
            buying_price REAL NOT NULL,
            selling_price REAL NOT NULL,
            profit REAL NOT NULL, 
            FOREIGN KEY(sale_id) REFERENCES sales(id),
            FOREIGN KEY(stock_id) REFERENCES products(id)
        )
    """)
    cur.execute("""
    CREATE TABLE IF NOT EXISTS sale_items_new(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        sale_id INTEGER NOT NULL, 
        product_name TEXT NOT NULL,
        quantity INTEGER NOT NULL, 
        price REAL NOT NULL,
        total REAL NOT NULL, 
        FOREIGN KEY(sale_id) REFERENCES sales(id)
        )
    """)

    cur.execute('''
    CREATE TABLE IF NOT EXISTS customers (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        phone TEXT,
        date_added DATE DEFAULT CURRENT_DATE
        
    )
    ''')

    cur.execute("""
    CREATE TABLE IF NOT EXISTS lendings (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        customer_id INTEGER NOT NULL,
        customer_name TEXT NOT NULL,
        product_id INTEGER NOT NULL,
        product_name TEXT NOT NULL,
        qty_lent INTEGER NOT NULL,
        amount_due REAL NOT NULL,
        profit_potential REAL NOT NULL,
        date_lent DATE NOT NULL,
        date_paid DATE,
        phone TEXT,
        status TEXT DEFAULT 'unpaid', -- 'unpaid' or 'paid'
        FOREIGN KEY (customer_id) REFERENCES customers(id),
        FOREIGN KEY (product_id) REFERENCES products(id)
    )
    """)

    # 3. STATS TABLE - make sure it exists
    cur.execute("""
    CREATE TABLE IF NOT EXISTS stats (
        id INTEGER PRIMARY KEY CHECK (id = 1),
        total_profit REAL DEFAULT 0,
        today_profit REAL DEFAULT 0
    )
    """)
    # Insert default row if none
    cur.execute("INSERT OR IGNORE INTO stats(id) VALUES(1)")

 
    cur.execute('''
    CREATE TABLE IF NOT EXISTS debts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        customer_id INTEGER ,
        total_amount REAL NOT NULL,
        customer_name TEXT,
        date_created TEXT,
        phone TEXT,
        amount_paid REAL DEFAULT 0,
        balance REAL NOT NULL,
        date_lent TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        status TEXT DEFAULT 'unpaid', -- 'unpaid' or 'paid',
        created_by TEXT,
        role TEXT,
        FOREIGN KEY (customer_id) REFERENCES customers (id)
    )
    ''')

    cur.execute('''
    CREATE TABLE IF NOT EXISTS debt_items (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        debt_id INTEGER NOT NULL,
        product_id INTEGER NOT NULL,
        qty INTEGER,
        price REAL NOT NULL,
        subtotal REAL NOT NULL,
        FOREIGN KEY (debt_id) REFERENCES debts (id)
     
    )
    ''')
    cur.execute('''
    CREATE TABLE IF NOT EXISTS money_out (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        amount REAL NOT NULL,
        reason TEXT,
        reference_id INTEGER, -- will store debt_id
        date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
    ''')
    
    cur.execute("SELECT COUNT(*) FROM categories")
    if cur.fetchone()[0] == 0:
        default_cats = ['Food', 'Drinks', 'Snacks', 'Households', 'Animal Feeds']
        cur.executemany('INSERT INTO categories (name) VALUES (?)', [(cat,) for cat in default_cats])
                     
        
    cur.execute("SELECT COUNT (*) FROM products")

    conn.commit()
    conn.close()
def sell_product(cart_items, payment_type='Cash'): # <-- ADDED payment_type
    """
    cart_items = [{'id':1, 'qty':2, 'selling_price':50, 'buying_price':30, 'name':'Oil'}]
    Deducts stock, logs profit, returns total profit made
    """
    from datetime import date
    
    conn = get_connection(DB_PATH)
    cur = conn.cursor()
    total_profit = 0

    for item in cart_items:
        prod_id = item['id']
        qty_sold = item['qty']
        sell_price = item['selling_price']
        buy_price = item['buying_price']
        name = item['name']

        # 1. Check stock
        cur.execute("SELECT quantity FROM products WHERE id=?", (prod_id,))
        result = cur.fetchone()
        if not result:
            print(f"Product {prod_id} not found")
            continue
        current_qty = result[0]
        
        if current_qty < qty_sold:
            print(f"Not enough stock for {name}")
            continue

        # 2. Deduct stock + Calculate
        new_qty = current_qty - qty_sold
        profit_per_item = sell_price - buy_price
        total_item_profit = profit_per_item * qty_sold
        total_amount = sell_price * qty_sold
        total_profit += total_item_profit

        # 3. Update product qty and status
        new_status = get_stock_status(new_qty)
        cur.execute("""
            UPDATE products
            SET quantity=?, stock_status=?
            WHERE id=?
        """, (new_qty, new_status, prod_id))

        # 4. Log the sale - ADDED payment_type
        cur.execute("""
            INSERT INTO sales(product_id, product_name, qty_sold, sell_price, buy_price, profit, total_amount, sale_date, payment_type)
            VALUES(?,?,?,?,?,?,?,?,?)
        """, (prod_id, name, qty_sold, sell_price, buy_price, total_item_profit, total_amount, date.today(), payment_type)) # <-- ADDED

    conn.commit()
    conn.close()
    print(f"Sale complete. Profit: KES {total_profit}")
    return total_profit


def get_sales_history(period="All"):
    """Return only PAID sales for history"""
    conn = get_connection(DB_PATH)
    cur = conn.cursor()

    query = """
        SELECT id, product_name, qty_sold, total_amount, payment_type, sale_date
        FROM sales
        WHERE payment_type IN ('Cash', 'Mpesa')
    """

    if period == "Today":
        query += " AND date(sale_date) = date('now')"
    elif period == "This Week":
        query += " AND sale_date >= date('now', '-7 days')"
    elif period == "This Month":
        query += " AND strftime('%Y-%m', sale_date) = strftime('%Y-%m', 'now')"

    query += " ORDER BY sale_date DESC" # Newest first

    cur.execute(query)
    rows = cur.fetchall()
    conn.close()

    sales_list = []
    for row in rows:
        sales_list.append({
            "id": row[0],
            "product_name": row[1],
            "qty_sold": row[2],
            "total_amount": row[3],
            "payment_type": row[4],
            "sale_date": row[5]
        })
    return sales_list

def get_profits():
    """Returns today's profit and total profit"""
    conn = get_connection(DB_PATH)
    cur = conn.cursor()

    # Total profit
    cur.execute("SELECT SUM(profit) FROM sales WHERE payment_type IN ('Cash')")
    total = cur.fetchone()[0] or 0

    # Today's profit - last 24 hours
    cur.execute("SELECT SUM(profit) FROM sales WHERE payment_type IN ('Cash') AND sold_at >= datetime('now', '-24 hours')")
    today = cur.fetchone()[0] or 0

    conn.close()
    return today, total  
def get_stock_status(qty):
    if qty <= 0:
        return "None"
    elif qty < 10:
        return "Low"
    else:
        return "High"
def add_new_product_to_stock(name, quantity, buying_price, selling_price, category, image_path='image/placeholder.png'):
    conn = get_connection(DB_PATH)
    cur = conn.cursor()

    stock_status = get_stock_status(quantity)

    # Check if product already exists
    cur.execute("SELECT id, quantity FROM products WHERE name=? AND category=?", (name, category))
    existing = cur.fetchone()

    if existing:
        # Update existing: add qty and update prices
        new_qty = existing[1] + quantity
        new_status = get_stock_status(new_qty)
        cur.execute("""
            UPDATE products
            SET quantity=?, buying_price=?, selling_price=?, image_path=?, stock_status=?
            WHERE id=?
        """, (new_qty, buying_price, selling_price, image_path, new_status, existing[0]))
    else:
        # Insert new
        cur.execute("""
            INSERT INTO products(name, quantity, buying_price, selling_price, category, image_path, stock_status)
            VALUES(?,?,?,?,?,?,?)
        """, (name, quantity, buying_price, selling_price, category, image_path, stock_status))

    conn.commit()
    conn.close()

def fetch_products_by_category(cat_name):
    """Get all products with category name from PRODUCTS table. Hides qty=0"""
    conn = get_connection(DB_PATH)
    cur = conn.cursor()

    cur.execute('''
        SELECT id, name, selling_price, image_path, quantity, buying_price, category
        FROM products
        WHERE category=? AND quantity > 0
    ''', (cat_name,))

    results = cur.fetchall()
    conn.close()
    print(f"Found {len(results)} products for {cat_name}")
    return results

def get_image_path(rel_path):
    base = os.path.dirname(os.path.abspath(__file__))
    return os.path.join(base, rel_path)
      #upto here


def add_cost_price_column():
    conn = get_connection(DB_PATH)
    cur = conn.cursor()
    try:
        cur.execute("ALTER TABLE products ADD COLUMN cost_price REAL NOT NULL DEFAULT 0")
        conn.commit()
        print("Added cost_price column")
    except sqlite3.OperationalError:
        pass
    conn.close()

add_cost_price_column()

         #==DEBTS STUFF IS  HERE===

def lend_product(customer_name, phone, cart_items):
    """
    Saves debtor, deducts stock, logs debt. Profit NOT added to home yet
    """
    conn = get_connection(DB_PATH)
    cur = conn.cursor()

    # 1. CHECK/CREATE CUSTOMER
    cur.execute("SELECT id FROM customers WHERE name=?", (customer_name,))
    result = cur.fetchone()
    if result:
        customer_id = result[0]
    else:
        cur.execute("INSERT INTO customers(name, phone) VALUES(?,?)", (customer_name, phone))
        customer_id = cur.lastrowid

    # 2. LEND EACH ITEM
    for item in cart_items:
        prod_id = item['id']
        qty_lent = item['qty']
        sell_price = item['selling_price']
        buy_price = item['buying_price']
        name = item['name']
        
        amount_due = sell_price * qty_lent
        profit_potential = (sell_price - buy_price) * qty_lent

        # Deduct stock
        cur.execute("SELECT quantity FROM products WHERE id=?", (prod_id,))
        current_qty = cur.fetchone()[0]
        new_qty = current_qty - qty_lent
        new_status = get_stock_status(new_qty)
        cur.execute("UPDATE products SET quantity=?, stock_status=? WHERE id=?", (new_qty, new_status, prod_id))

        # Log the debt
        cur.execute("""
            INSERT INTO lendings(customer_id, customer_name, product_id, product_name, qty_lent, amount_due, profit_potential, date_lent, phone, status)
            VALUES(?,?,?,?,?,?,?,?,?,?)
        """, (customer_id, customer_name, prod_id, name, qty_lent, amount_due, profit_potential, date.today(), phone, 'unpaid'))

    conn.commit()
    conn.close()
    print(f"Debt recorded for {customer_name}")


def collect_debt(lending_id):
    """
    When user taps COLLECT. Moves profit to home and marks paid
    """
    conn = get_connection(DB_PATH)
    cur = conn.cursor()
    
    # Get profit and amount
    cur.execute("SELECT profit_potential, amount_due FROM lendings WHERE id=?", (lending_id,))
    profit, amount = cur.fetchone()
    
    # 1. Mark as paid
    cur.execute("UPDATE lendings SET status='paid', date_paid=? WHERE id=?", (date.today(), lending_id))
    
    # 2. ADD PROFIT TO HOME
    cur.execute("UPDATE stats SET total_profit = total_profit +? WHERE id=1", (profit,))
    cur.execute("UPDATE stats SET today_profit = today_profit +? WHERE id=1", (profit,))
    
    conn.commit()
    conn.close()
    print(f"Collected KES {amount}. Profit KES {profit} added to home")


def get_total_debt():
    """Total unpaid debt. This is your 'Deni' / Money Owed to you"""
    conn = get_connection(DB_PATH)
    cur = conn.cursor()
    cur.execute("SELECT SUM(balance) FROM debts WHERE status='unpaid'")
    result = cur.fetchone()[0]
    conn.close()
    return float(result) if result else 0.0


def get_total_debtors():
    """Number of people with unpaid debt"""
    conn = get_connection(DB_PATH)
    cur = conn.cursor()
    cur.execute("SELECT COUNT(DISTINCT customer_id) FROM debts WHERE status='unpaid'")
    result = cur.fetchone()[0]
    conn.close()
    return result if result else 0


def get_all_debts():
    """For Denibook screen table"""
    conn = get_connection(DB_PATH)
    cur = conn.cursor()
    cur.execute("SELECT id, customer_name, phone, SUM(amount_due), date_lent FROM lendings WHERE status='unpaid' GROUP BY customer_id")
    debts = cur.fetchall()
    conn.close()
    return debts # returns list of (id, name, phone, total_debt, date)
def save_debt_new(customer_name, phone, cart_items, created_by, role, payment_type='Deni'): # <-- ADDED
    """Save debt to debts + debt_items, deduct stock, log money_out + sales"""
    conn = get_connection(DB_PATH)
    cur = conn.cursor()

    # 1. CHECK/CREATE CUSTOMER
    cur.execute("SELECT id FROM customers WHERE name=?", (customer_name,))
    result = cur.fetchone()
    if result:
        customer_id = result[0]
    else:
        cur.execute("INSERT INTO customers(name, phone) VALUES(?,?)", (customer_name, phone))
        customer_id = cur.lastrowid

    # 2. CALCULATE TOTALS
    total_amount = sum([i['selling_price'] * i['qty'] for i in cart_items])
    total_profit = sum([(i['selling_price'] - i['buying_price']) * i['qty'] for i in cart_items])

    # 3. INSERT INTO debts TABLE
    cur.execute("""
        INSERT INTO debts(customer_id, customer_name, phone, total_amount, balance, created_by, role, status)
        VALUES(?,?,?,?,?,?,?,?)
    """, (customer_id, customer_name, phone, total_amount, total_amount, created_by, role, 'unpaid'))
    debt_id = cur.lastrowid

    # 4. INSERT ITEMS + DEDUCT STOCK + LOG TO SALES
    for item in cart_items:
        prod_id = item['id']
        qty = item['qty']
        price = item['selling_price']
        buy_price = item['buying_price'] # <-- needed for sales table
        name = item['name'] # <-- needed for sales table
        subtotal = price * qty
        profit = (price - buy_price) * qty

        cur.execute("""
            INSERT INTO debt_items(debt_id, product_id, qty, price, subtotal)
            VALUES(?,?,?,?,?)
        """, (debt_id, prod_id, qty, price, subtotal))

        # Deduct stock
        cur.execute("UPDATE products SET quantity = quantity -? WHERE id=?", (qty, prod_id))

        # 4B. LOG TO SALES TABLE AS DENI
        cur.execute("""
            INSERT INTO sales(product_id, product_name, qty_sold, sell_price, buy_price, profit, total_amount, sale_date, payment_type)
            VALUES(?,?,?,?,?,?,?,?,?)
        """, (prod_id, name, qty, price, buy_price, profit, subtotal, date.today(), payment_type)) # <-- ADDED

    # 5. LOG TO MONEY_OUT TABLE
    #cur.execute("INSERT INTO money_out(amount, reason, reference_id) VALUES(?,?,?)",
                #(total_amount, 'Debt Given', debt_id))

    conn.commit()
    conn.close()
    return total_amount, total_profit


def get_debts_for_user(user_role, username):
    """Get debts. Employer sees all, Employee sees own"""
    conn = get_connection(DB_PATH)
    cur = conn.cursor()
    if user_role == 'employer':
        cur.execute("SELECT * FROM debts WHERE status='unpaid'")
    else:
        cur.execute("SELECT * FROM debts WHERE status='unpaid' AND created_by=?", (username,))
    debts = cur.fetchall()
    conn.close()
    return debts

def migrate_add_profit_to_debts():
    """Run this once to add profit column if it doesn't exist"""
    conn = get_connection(DB_PATH)
    cur = conn.cursor()
    try:
        cur.execute("ALTER TABLE debts ADD COLUMN profit REAL DEFAULT 0")
        conn.commit()
    except sqlite3.OperationalError:
        # Column already exists
        pass
    conn.close()

def get_all_unpaid_debts():
    """Returns list of unpaid debts for Denibook list"""
    conn = get_connection(DB_PATH)
    cur = conn.cursor()
    cur.execute("""
        SELECT id, customer_id, customer_name, phone, total_amount, profit, date_lent 
        FROM debts 
        WHERE status = 'unpaid' 
        ORDER BY date_lent DESC
    """)
    debts = cur.fetchall()
    conn.close()
    return debts

def get_total_profit_out_on_deni():
    """Stat for top card"""
    conn = get_connection(DB_PATH)
    cur = conn.cursor()
    cur.execute("SELECT SUM(profit) FROM debts WHERE status = 'unpaid'")
    total = cur.fetchone()[0]
    conn.close()
    return total if total else 0

def get_debt_items(debt_id):
    """Get products for expanded view"""
    conn = get_connection(DB_PATH)
    cur = conn.cursor()
    cur.execute("""
        SELECT di.product_id, p.name, di.qty, di.price, di.subtotal
        FROM debt_items di
        JOIN products p ON di.product_id = p.id
        WHERE di.debt_id =?
    """, (debt_id,))
    items = cur.fetchall()
    conn.close()
    return items

    #++++++PRODUCTS+++++
def add_product(name, price, image, stock, category_name):
    try:
         
        conn = get_connection(DB_PATH)
        cur = conn.cursor()
        clean_cat = category_name.upper().strip()
        cur.execute("SELECT id FROM categories WHERE UPPER(name) =?", (clean_cat,))
        row = cur.fetchone()

        if row is None:
            cur.execute("""
            INSERT INTO categories (name) VALUES (?) """, (clean_cat,))
            cat_id = cur.lastrowid
            print(f"Created new category: {clean_cat} -> id={cat_id} ")
        else:
            cat_id = row[0]
        cur.execute("SELECT id FROM products WHERE name=?", (name, ))
        if cur.fetchone():
            conn.close()
            return False 
        print(f"Product '{name}' alreay exists")

    
        cur.execute(
             "INSERT INTO products(name,price, image, stock, category_id) VALUES(?,?,?,?,?)",
             (name, price, image, int(stock), cat_id)

        )
        conn.commit()
        print(f"Added: {name} | Ksh {price} | Stock:{stock} | Cat: {category_name}")
        
        return True, f"{name} Added successfully"
    
    except sqlite3.IntegrityError as e:
        return False, str(e)
        
    finally:
        conn.close()

def add_product_from_fab(name):
        clean_name = name.lower().strip()
        images_root = IMG_FOLDER

        if not os.path.exists(images_root):
             print(("ERROR: 'images' folder not found"))
             return None, None
        
        for category in os.listdir("images"):
             
            cat_path = os.path.join(IMG_FOLDER, category)
            if os.path.isdir(cat_path):
                 

 
                print(f" Looking in folder: {cat_path}")
                for ext in ['.png','.jpg','.jpeg']:
                    path = os.path.join(cat_path, clean_name + ext)
                    print(f"Checking: {path} Exists: {os.path.exists(path)}")
                    if os.path.exists(path):
                        print(f"Found it Boss: {path}")
                        return path, category
        print("Not Found Sir")
        return None, None # No img has been 


def add_product_full(name , price, stock, category):
     img_path = add_product_from_fab(name, category)
     if img_path is None:
          return False
     return add_product(name, price, img_path, stock, category)


def load_products(self):
    conn = get_connection(DB_PATH)
    cur = conn.cursor()
    cur.execute("SELECT name , price, image, stock FROM products")
    rows = cur.fetchall()
    conn.close()

    data = []
    for name, price, image, stock in rows:
         data.append({
              'name': name,
              'sell': price,
              'root_image': image,
              'index': 0
         })
    return data
# Run once on import
def save_sale(cart_items):
    """Save 1 receipt to sales, and each product to Sale_items"""
    conn = get_connection(DB_PATH)
    cur = conn.cursor()
    today = date.today()

    # 1. First calculate total for the whole receipt
    receipt_total = sum([item['selling_price'] * item['qty'] for item in cart_items])
    receipt_profit = sum([(item['selling_price'] - item['buying_price']) * item['qty'] for item in cart_items])

    # 2. Insert 1 row into sales table for the whole receipt
    # Using first item's data just to fill required columns. Main thing is total_amount
    first_item = cart_items[0]
    cur.execute("""
        INSERT INTO sales(product_id, qty_sold, product_name, buy_price, sell_price, 
        qty, sale_price, total_profit, cost_price, total_amount, sale_date, profit)
        VALUES(?,?,?,?,?,?,?,?,?,?,?,?)
    """, (
        first_item['id'], 0, "Multiple Items", 0, 0, # dummy data for product fields
        0, 0, receipt_profit, 0, receipt_total, today, receipt_profit
    ))
    sale_id = cur.lastrowid # Get the id of this new receipt

    # 3. Insert each product into Sale_items table
    for item in cart_items:
        profit = (item['selling_price'] - item['buying_price']) * item['qty']
        
        cur.execute("""
            INSERT INTO Sale_items(sale_id, stock_id, quantity_sold, buying_price, selling_price, profit)
            VALUES(?,?,?,?,?,?)
        """, (sale_id, item['id'], item['qty'], item['buying_price'], item['selling_price'], profit))
        
        # 4. Deduct stock
        cur.execute("UPDATE products SET quantity = quantity -? WHERE id=?", (item['qty'], item['id']))

    conn.commit()
    conn.close()

def get_cash_in_hand():
    """Cash = Total CASH Sales - Total Expenses. Excludes Deni"""
    conn = get_connection(DB_PATH)
    cur = conn.cursor()
    
    # 1. CASH IN HAND = SUM of only CASH sales minus expenses
    cur.execute("SELECT SUM(total_amount) FROM sales WHERE payment_type='Cash'")
    total_cash_sales = cur.fetchone()[0] or 0
    
    # 2. TOTAL ITEMS SOLD CASH = SUM of qty_sold for CASH only
    cur.execute("SELECT SUM(qty_sold) FROM sales WHERE payment_type='Cash'")
    total_sales_count = cur.fetchone()[0] or 0
    
    # 3. EXPENSES
    
    
    conn.close()
    return  total_cash_sales, total_sales_count, 0

create_tables()

