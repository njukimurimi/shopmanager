from kivymd.uix.screen import MDScreen
from kivymd.uix.dialog import MDDialog
from kivymd.uix.button import MDFlatButton
from kivymd.app import MDApp
from kivy.app import App
from firebase_admin import db
from datetime import datetime
import json
import os

DEVICE_ID_FILE = "device_id.txt"
SAVE_FILE = "selected_payment.json"
class SetupScreen(MDScreen):
    dialog = None
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.device_id = self.get_device_id()
        self.dialog = None

    def get_device_id(self):
        if os.path.exists(DEVICE_ID_FILE):
            with open(DEVICE_ID_FILE, "r") as f:
                return f.read().strip()
        return ""

    def load_payment_data(self):
        if os.path.exists(SAVE_FILE):
            with open(SAVE_FILE, "r") as f:
                return json.load(f)
        return None
    def show_dialog(self, title, text):
        if self.dialog:
            self.dialog.dismiss()
        self.dialog = MDDialog(
            title=title,
            text=text,
            buttons=[MDFlatButton(text="OK", on_release=lambda x: self.dialog.dismiss())]
        )
        self.dialog.open()

    def save_and_continue(self):
        username = self.ids.username_input.text.strip()
        if len(username) < 3:
            self.show_dialog("Error", "Username must be at least 3 characters")
            return
            
       

        payment_data = self.load_payment_data()
        if not payment_data:
            #self.show_dialog("Error", "Payment info missing. Please select plan again")
            #self.manager.current = "gateway"
            self.manager.current = "home"
            return

        plan = payment_data["plan"]
        amount = payment_data["amount"]

        # Get mpesa code from gateway screen
        gateway = self.manager.get_screen("gateway")
        mpesa_code = getattr(gateway, "mpesa_code", None)
        
        if not mpesa_code:
            self.show_dialog("Error", "M-Pesa code missing")
            return
        app = App.get_running_app()
        app.username = username # <-- ADD THIS
        self.manager.current = "home"
        
        # 1. Save to user profile
        user_ref = db.reference(f"dongmurih/users/{self.device_id}")
        user_ref.update({
            "username": username,
            "plan": plan,
            "amount": amount,
            "mpesa_code": mpesa_code,
            "status": "pending_approval",
            "created_at": datetime.now().isoformat(),
            "activated": False
        })

        # 2. Update admin queue with username
        queue_ref = db.reference(f"dongmurih/admin_queue/{mpesa_code}")
        queue_ref.update({
            "username": username,
            "status": "pending"
        })

        # 3. Clear saved payment file
        if os.path.exists(SAVE_FILE):
            os.remove(SAVE_FILE)

        self.show_dialog("Success", "Details submitted. Waiting for admin approval.")
        self.manager.current = "home"



    def show_error(self, text):
        if not self.dialog:
            self.dialog = MDDialog(
                text=text,
                buttons=[MDFlatButton(text="OK", on_release=lambda x: self.dialog.dismiss())]
            )
        else:
            self.dialog.text = text
        self.dialog.open()

    def lock_fields(self):
        # Disable username input + save button
        self.ids.username_input.disabled = True
        self.ids.save_button.disabled = True
        self.ids.username_input.hint_text = "Locked - Waiting for approval"
        self.ids.username_input.opacity = 0.5
        self.ids.save_button.opacity = 0.5

    def unlock_fields(self):
        # Re-enable after approval
        self.ids.username_input.disabled = False
        self.ids.save_button.disabled = False
        self.ids.username_input.hint_text = "Enter Username"
        self.ids.username_input.opacity = 1
        self.ids.save_button.opacity = 1
        #Toast.show("Account Activated!") # optional


