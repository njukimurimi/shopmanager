from kivymd.uix.dialog import MDDialog
from kivymd.uix.button import MDFlatButton, MDRaisedButton
from kivymd.uix.textfield import MDTextField
from kivymd.uix.boxlayout import MDBoxLayout
from popups import ApprovalPopup
import pyperclip
import webbrowser

import uuid
import json
import os
import socket

from firebase_manager import db # Use your firebase_manager db, not firebase_admin directly
from datetime import datetime
SAVE_FILE = "selected_payment.json"

def get_device_id():
    DEVICE_ID_FILE = "device_id.txt"
    if os.path.exists(DEVICE_ID_FILE):
        with open(DEVICE_ID_FILE, "r") as f:
            return f.read().strip()
    new_id = str(uuid.uuid4())
    with open(DEVICE_ID_FILE, "w") as f:
        f.write(new_id)
    return new_id

class PaymentPopup:
    def __init__(self, plan_name, amount, on_submit_callback, name = "setup"):
        self.plan_name = plan_name
        self.amount = amount
        self.on_submit_callback = on_submit_callback
        self.pochi_number = "0712879226"
        self.dialog = None
        self.code_field = None
        self.name = name

    def has_internet(self):
        try:
            socket.create_connection(("8.8.8.8", 53), timeout=2)
            return True
        except:
            return False

    def save_selection(self):
        data = {"plan": self.plan_name, "amount": self.amount}
        with open(SAVE_FILE, "w") as f:
            json.dump(data, f)

    @staticmethod
    def load_selection():
        if os.path.exists(SAVE_FILE):
            with open(SAVE_FILE, "r") as f:
                return json.load(f)
        return None

    def copy_number(self):
        pyperclip.copy(self.pochi_number)

    def pay_now(self):
        url = f"tel:*234#"
        webbrowser.open(url)

    def submit_code(self):
        if not self.has_internet():
            self.show_error("No Internet", "Connect to internet to submit")
            return

        mpesa_code = self.code_field.text.strip().upper()
            
        if len(mpesa_code) < 8:
            self.show_error("Invalid Code", "M-Pesa code must be at least 8 characters")
            return
  
        device_id = get_device_id() # Now uses same file as gateway
        
        # Check if code already pending
        if db.reference(f"dongmurih/used_codes/{mpesa_code}").get():
            self.show_error("Invalid", "This code is already used or pending")
            return

        user_type = "new" if self.name == "setup" else "renew"
        self.dialog.dismiss() # close payment popup

        # Save to admin_queue with CODE as key, not device_id
        db.reference(f"dongmurih/admin_queue/{mpesa_code}").set({
            "device_id": device_id,
            "plan": self.plan_name,
            "amount": self.amount,
            "status": "pending",
            "timestamp": datetime.now().isoformat(),
            "type": user_type
        })
     
        db.reference(f"dongmurih/used_codes/{mpesa_code}").set(True)

        # Call gateway callback to handle screen switch
        self.on_submit_callback(self.plan_name, self.amount, mpesa_code)
        
        # Show waiting popup
        popup = ApprovalPopup(user_type=user_type)
        popup.open()
        
    def show_error(self, title, msg):
        MDDialog(
            title=title,
            text=msg,
            buttons=[MDFlatButton(text="OK", on_release=lambda x: x.parent.parent.dismiss())]
        ).open()

    def show(self):
        self.code_field = MDTextField(
            hint_text="Enter M-Pesa Confirmation Code",
            helper_text="Example: NHK7D8K9L",
            mode="fill"
        )

        content = MDBoxLayout(orientation="vertical", spacing=10, padding=10)
        content.add_widget(self.code_field)

        self.dialog = MDDialog(
            title=f"Pay Ksh {self.amount} via Pochi",
            text=f"1. Lipa na M-Pesa > Buy Goods\n2. Pochi Number: {self.pochi_number}\n3. Amount: Ksh {self.amount}\n\nPay exact amount. Wrong amounts will be rejected.",
            type="custom",
            content_cls=content,
            buttons=[
                MDFlatButton(text="COPY NUMBER", on_release=lambda x: self.copy_number()),
                MDFlatButton(text="PAY NOW", on_release=lambda x: self.pay_now()),
                MDRaisedButton(text="I HAVE PAID", on_release=lambda x: self.submit_code()),
            ],
        )
        self.dialog.open()
