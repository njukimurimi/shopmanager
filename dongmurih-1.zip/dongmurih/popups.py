from kivy.clock import Clock
from kivy.uix.popup import Popup
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from firebase_manager import db
from kivy.app import App
import os
import uuid

DEVICE_ID_FILE = "device_id.txt"
def get_device_id():
    if os.path.exists(DEVICE_ID_FILE):
        with open(DEVICE_ID_FILE, "r") as f:
            return f.read().strip()
    return str(uuid.uuid4())

class ApprovalPopup(Popup):
    def __init__(self, user_type="new", **kwargs):
        # 1. Build the 1 content widget first
        layout = BoxLayout(orientation='vertical', padding=20, spacing=15)
        
        if user_type == "new":
            status = "⏳ Waiting for Admin Approval"
            sub = "Please wait while we verify your payment"
        else:
            status = "⏳ Renewal Pending" 
            sub = "Please wait while we verify your payment"

        self.status_label = Label(text=status, color=(0,0,0,1), font_size='18sp', bold=True, halign="center")
        self.sub_label = Label(text=sub, color=(0,0,0,1), font_size='14sp', halign="center")
        
        layout.add_widget(self.status_label)
        layout.add_widget(self.sub_label)

        # 2. Now call super with content = layout
        super().__init__(title="Pending Approval", content=layout, size_hint=(0.8, 0.4), auto_dismiss=False, **kwargs)
        
        self.user_type = user_type
        self.check_event = None
        self.start_checking()
    
    def start_checking(self):
        self.check_event = Clock.schedule_interval(self.check_approval, 3)

    def check_approval(self, dt):
        device_id = get_device_id()
        try:
            user_data = db.reference(f"dongmurih/users/{device_id}").get()
        except:
            return
        
        if user_data and user_data.get("activated") == True:
            self.status_label.text = "✅ Approved"
            self.sub_label.text = "Welcome back! Unlocking now..."
            
            Clock.schedule_once(self.close_and_unlock, 2)
            Clock.unschedule(self.check_event)

    def close_and_unlock(self, dt):
        self.dismiss()
        app = App.get_running_app()
        if self.user_type == "new":
            app.root.get_screen("setup").unlock_fields()
        else:
            app.root.get_screen("home").unlock_vpn_button()
