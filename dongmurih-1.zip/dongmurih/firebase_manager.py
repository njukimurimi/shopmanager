import pyrebase
from datetime import datetime, timedelta
import firebase_admin
from firebase_admin import credentials, db
cred = credentials.Certificate("serviceAccountKey.json")
firebase_admin.initialize_app(cred, {
    'databaseURL': 'https://dongmurih-default-rtdb.firebaseio.com/'
})



def get_device_id(app_db):
    device_id = app_db.get_setting('device_id')
    if not device_id:
        import uuid
        device_id = 'DONGMURIH-' + str(uuid.uuid4())[:6].upper()
        app_db.save_setting('device_id', device_id)
    return device_id

def sync_from_firebase(app_db, device_id):
    """Try get fresh data. Returns dict or None"""
    try:
        data = db.child("users").child(device_id).get().val()
        if data:
            if 'activated' in data:
                app_db.save_setting('activated', str(data.get('activated')).lower())
            if 'expiry_date' in data:
                app_db.save_setting('expiry_date', data.get('expiry_date', ''))
                
            app_db.save_setting('last_check_date', str(datetime.now().date()))
            return data
    except Exception as e:
        print("Firebase sync failed:", e)
    return None

def is_in_grace(app_db):
    """Returns: 'active', 'grace', 'blocked', days_left"""
    today = datetime.now().date()
    grace_days = 3
    
    expiry_str = app_db.get_setting('expiry_date')
    if not expiry_str:
        return 'blocked', 0

    expiry = datetime.strptime(expiry_str, "%Y-%m-%d").date()
    grace_end = expiry + timedelta(days=grace_days)

    if today >= grace_end:
        return 'blocked', 0
    if today >= expiry:
        days_left = (grace_end - today).days
        return 'grace', days_left
    return 'active', 0