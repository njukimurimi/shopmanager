from kivymd.uix.screen import MDScreen
from kivymd.uix.list import OneLineAvatarIconListItem, IconRightWidget
from kivymd.uix.dialog import MDDialog
from kivymd.uix.button import MDFlatButton, MDRaisedButton
from firebase_admin import db
from datetime import datetime, timedelta
ADMIN_USER = "admin"
ADMIN_PASS = "murihnjuki&&%%"
class AdminLoginScreen(MDScreen):
    def login(self):
        if self.ids.user.text == ADMIN_USER and self.ids.passw.text == ADMIN_PASS:
            self.manager.current = "admin_dashboard"
            self.manager.get_screen("admin_dashboard").load_queue()
        else:
            self.ids.error.text = "Wrong password"
class AdminScreen(MDScreen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.dialog = None
        self.load_pending_payments()

    def load_pending_payments(self):
        ref = db.reference("dongmurih/admin_queue")
        payments = ref.get()
        self.ids.container.clear_widgets()
        
        if not payments: return

        for code, data in payments.items():
            if data.get("status") == "pending":
                item = OneLineAvatarIconListItem(
                    text=f"{data['username']} - {data['plan']} Ksh{data['amount']}",
                    secondary_text=f"Code: {code}"
                )
                item.bind(on_release=lambda x, c=code, d=data: self.show_approval_dialog(c, d))
                self.ids.container.add_widget(item)

    def show_approval_dialog(self, code, data):
        plan = data["plan"]
        days = 30 if plan == "Monthly" else 365
        expiry_date = datetime.now() + timedelta(days=days)

        self.dialog = MDDialog(
            title=f"Approve {data['username']}?",
            text=f"Plan: {plan}\nAmount: Ksh {data['amount']}\nCode: {code}\n\nThis will activate until {expiry_date.date()}",
            buttons=[
                MDFlatButton(text="REJECT", on_release=lambda x: self.reject(code, data)),
                MDRaisedButton(text="APPROVE", on_release=lambda x: self.approve(code, data, expiry_date)),
            ],
        )
        self.dialog.open()

    def approve(self, code, data, expiry_date):
        device_id = data["device_id"]
        # 1. Activate user and set expiry
        db.reference(f"dongmurih/users/{device_id}").update({
            "activated": True,
            "expiry_date": expiry_date.isoformat(),
            "status": "active"
        })
        # 2. Mark queue as approved
        db.reference(f"dongmurih/admin_queue/{code}").update({"status": "approved"})
        self.dialog.dismiss()
        self.load_pending_payments()

    def reject(self, code, data):
        db.reference(f"dongmurih/admin_queue/{code}").update({"status": "rejected"})
        self.dialog.dismiss()
        self.load_pending_payments()

    def logout(self):
            self.manager.current = "gateway"
    def show_dialog(self, title, text):
        dialog = MDDialog(
            title=title,
            text=text,
            buttons=[MDFlatButton(text="OK", on_release=lambda x: dialog.dismiss())]
        )
        dialog.open()