from kivy.app import App
from kivymd.uix.screen import MDScreen
from kivy.uix.popup import Popup
from kivymd.uix.label import MDLabel
#from firebase_admin import db2
from datetime import datetime
import os
from database import get_profits

import database as db
from kivy.clock import Clock
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.graphics import Color, RoundedRectangle, Line
from kivymd.uix.button import MDFlatButton, MDIconButton
from kivymd.uix.list import OneLineIconListItem, IconLeftWidget
from kivymd.uix.behaviors import HoverBehavior
from kivy.properties import BooleanProperty
from kivy.utils import platform
# 1. Custom hover item
class HoverListItem(HoverBehavior, OneLineIconListItem):
    hovered = BooleanProperty(False)

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.bg_color = (0,0,0,0) # transparent
        self.text_color = (0, 1, 1, 1) # Neon Cyan default
        Clock.schedule_once(self.update_stats, 0) # run once on start
        

    def on_enter(self):
        self.hovered = True
        self.text_color = (1, 0, 0, 1) # Red on hover
        self.ids._left_container.children[0].icon_color = (1, 0, 0, 1) # Icon red too

    def on_leave(self):
        self.hovered = False
        self.text_color = (0, 1, 1, 1) # Back to Neon Cyan
        self.ids._left_container.children[0].icon_color = (0, 1, 1, 1) # Icon cyan too
class SettingsPopup(Popup):
    pass

DEVICE_ID_FILE = "device_id.txt"
class HomeScreen(MDScreen): # renamed
    settings_popup = None
    waiting_for_approval = False
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.device_id = self.get_device_id()
        Clock.schedule_once(lambda dt: self.update_stats(), 0.2)

    def get_device_id(self):
        if os.path.exists(DEVICE_ID_FILE):
            with open(DEVICE_ID_FILE, "r") as f:
                return f.read().strip()
        return ""
    def on_pre_enter(self):
        app = App.get_running_app()
        if hasattr(app, 'username'): # check if username exists
            self.ids.username_label_top.text = app.username
            self.ids.username_label.text = f"{app.username}\nMANAGER"
            
    def on_enter(self):
        self.check_activation()
        app = App.get_running_app()
    
        # Hide alert if no debtors
        if App.get_running_app().total_debtors == 0:
            self.ids.deni_alert_card.opacity = 0
            self.ids.deni_alert_card.disabled = True
        else:
            self.ids.deni_alert_card.opacity = 1
            self.ids.deni_alert_card.disabled = False

    #def check_activation(self):
        try:
            ref = db.reference(f"dongmurih/users/{self.device_id}")
            user_data = ref.get()

            if not user_data:
                return

            if user_data.get("activated"):
                expiry = datetime.fromisoformat(user_data["expiry_date"])
                days_left = (expiry - datetime.now()).days
                self.ids.status_label.text = f"ACTIVE\nPlan: {user_data['plan']}\nExpires in {days_left} days"
                self.ids.connect_btn.disabled = False
            else:
                self.ids.status_label.text = "STATUS: Waiting for Admin Approval\nYou will be notified once activated"
                self.ids.connect_btn.disabled = True
                self.waiting_for_approval = False
        except:
            return

    def show_settings_menu(self):
        if self.settings_popup:
            self.settings_popup.dismiss()

        # 1. The content layout - no padding so it sticks to top
        content = BoxLayout(orientation='vertical', padding=[10, 0, 10, 0], spacing=2, size_hint_y=None)
        content.bind(minimum_height=content.setter('height'))

        # 2. The options list: [text, icon, function]
        options = [
            ["Change Username", "account-edit", self.change_username],
            ["Invite a Friend", "account-plus", self.invite_friend],
            ["Backup & Storage", "cloud-upload", self.backup_storage],
            ["About App", "information", self.about_app],
        ]

        for text, icon, func in options:
            item = OneLineIconListItem(text=text, on_release=func, theme_text_color = "Custom",
                                    text_color = (0, 1, 1, 1),  height = "36dp",bg_color=(0,0,0,.6)) # transparent bg
            item.add_widget(IconLeftWidget(icon=icon))

            # Neon Cyan text and icon
            item.text_color = (1, 0, 0, 1)
            item.ids._left_container.children[0].theme_text_color = "Custom"
            item.ids._left_container.children[0].icon_color = (0, 1, 1, 1)
            

            content.add_widget(item)

        # 3. The Popup itself - positioned at top right
        self.settings_popup = Popup(
            title='',
            content=content,
            size_hint=(None, None),
            size=(260, content.minimum_height),
            pos_hint={'top': 0.78, 'right': 0.98}, # top right corner
            auto_dismiss=True,
            background='', # removes default bg image
            background_color=(0,0,0,0), # makes popup fully transparent
            separator_height=0,
            overlay_color=(0,0,0,0) # removes the dark overlay behind popup
        )

        self.settings_popup.open()

    # Dummy functions for now
    def change_username(self, *args):
        # 1. Get the app's screen manager
        sm = self.manager

        # 2. Switch to setup screen
        sm.current = 'setup'

        # 3. Optional: Add a transition so it slides
        from kivy.uix.screenmanager import SlideTransition
        sm.transition = SlideTransition(direction='left', duration=0.2)

        print("Navigating to Setup Screen")
        print("Change Username clicked")
        self.settings_popup.dismiss()

    def invite_friend(self, *args):
        print("Invite Friend clicked")
        self.settings_popup.dismiss()

    def backup_storage(self, *args):
        print("Backup clicked")
        self.settings_popup.dismiss()

    def about_app(self, *args):
        print("About clicked")
        self.settings_popup.dismiss()


    def update_stats(self, dt=None):
        today, total = get_profits()
        self.ids.todays_profit_label.text = f"KES {today:,.0f}"
        self.ids.total_profit_label.text = f"KES {total:,.0f}"
        #self.ids.today_profit_label.text = f"Today: KES {today}" # change id to yours
        #self.ids.total_profit_label.text = f"Total: KES {total}" # change id to yours
        print(f"Dashboard Updated. Today: {today}, Total: {total}")

        
        debtors = db.get_total_debtors()
        if debtors >= 5:
            self.ids.deni_alert_label.text = f"ALERT: {debtors} Debtors. Collect Money!"
            self.ids.deni_alert_label.opacity = 1 # make it visible
        else:
            self.ids.deni_alert_label.opacity = 0 # hide it


    def lock_vpn_button(self):
        self.ids.connect_button.disabled = True
        self.ids.connect_button.text = "⏳ Waiting Approval"
        self.ids.connect_button.opacity = 0.5

    def unlock_vpn_button(self):
        self.ids.connect_button.disabled = False
        self.ids.connect_button.text = "CONNECT VPN"
        self.ids.connect_button.opacity = 1
        #Toast.show("Subscription Activated!")
